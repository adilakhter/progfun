* The max of a single element list is equal to that element
* The max of a list is greater than or equal to all elements of the list