/* 
3. The third case is the first that matches, with `x` bound to 1 and `y` bound to 2. 
*/