`seq` distributes over `kor`, much like multiplication distributes over addition:

  seq(a, kor(b,c)) == kor(seq(a,b), seq(a,c))