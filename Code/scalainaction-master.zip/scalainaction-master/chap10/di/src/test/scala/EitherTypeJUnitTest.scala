package scala.book.ch9.junitexample {
  import junit.framework.Assert._
  import org.junit.Test
  
  class CalculatePriceServiceTest {
  }
}