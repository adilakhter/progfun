// Run with >scala Programmer.scala  or
// run with the REPL in chap01/ via
// scala> :load Programmer.scala

class ScalaProgrammer(
  var name:String, 
  var language:String,
  var favDrink:String
  )
