package object bar {
	val minimumAge = 18
  def verifyAge = {}
}
