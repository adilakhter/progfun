package bar 
class BarTender {
	def serveDrinks = {
		verifyAge
	}
}	

