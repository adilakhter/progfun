// README.txt
How to run the examples.

Start sbt (0.11.2) in chap03/scala-mongo-driver-sbt >sbt
Start the Mongo Server from a command line shell (assuming it is installed and in the path and running on port=27017)> mongod
in sbt >run QuickTour
in sbt >run TestFindQuery
