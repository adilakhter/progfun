// Start the REPL and load the file with> :load RichConsole.scala

object RichConsole {
  def p(x: Any) = println(x)
}