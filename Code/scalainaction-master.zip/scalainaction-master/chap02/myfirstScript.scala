// Run with >scala myfirstScript.scala Hello World
// in chap02/

args.foreach(println _)