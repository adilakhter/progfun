Forked to support the author of Scala in Action Nilanjan Raychauhuri via Feedback and bugfixes and for sure to learn :-)

chap09 now moved to sbt 0.11.2 with specs2
chap05 moved typical sbt project structure to sbt 0.11.2
chap08 move to sbt 0.11.2. Checked the code for executability and refactored JavaScalaActors to be a standalone eclipse project which can also be run with sbt.
chap10 checked for compilability and moved to sbt 0.11.2
chap01 checked for compilability and added run comments
chap02 checked for compilability, added run comments and added restclient sbt 0.11.2 project
chap03 checked for compilability, added run comments and added scala-mongo-driver-sbt as the scala-mongo-driver project build be sbt 0.11.2 project
chap04 checked (on Windows) for compilability, added run comments and fixed some compile bugs against Scala 2.9.1.
